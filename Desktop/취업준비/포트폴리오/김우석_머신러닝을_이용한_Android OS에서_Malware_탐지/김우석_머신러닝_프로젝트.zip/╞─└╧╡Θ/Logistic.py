import os
import pandas as pd
import numpy as np
from sklearn import metrics
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Perceptron
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score,classification_report
from pandas import Series, DataFrame
import statsmodels.api as sm
import matplotlib.pyplot as plt 
from sklearn.metrics import auc 

#information value 값 계산해주는 함수
def IV_calc(data,var):
    if data[var].dtypes==object:#이산변수인 경우
        data['var']=pd.cut(data[var].astype('int'),10)
        dataf=data.groupby('var')['label'].agg(['count','sum'])
        dataf.columns=["Total","Bad"]
        dataf["Good"]=dataf["Total"]-dataf["Bad"]
        dataf["Bad_per"]=dataf["Bad"]/dataf["Bad"].sum()
        dataf["Good_per"]=(dataf["Good"])/dataf["Good"].sum()
        dataf["I_V"]=(dataf["Good_per"]-dataf["Bad_per"])*np.log(dataf["Good_per"]/dataf["Bad_per"])
        return dataf

    else:#연속변수인 경우
        data['bin_var']=pd.qcut(data[var].rank(method='first'),10)
        dataf=data.groupby(['bin_var'])['label'].agg(['count','sum'])
        dataf.columns=["Total","Bad"]
        dataf["Good"]=dataf["Total"]-dataf["Bad"]
        dataf["Bad_per"]=dataf["Bad"]/dataf["Bad"].sum()
        dataf["Good_per"]=dataf["Good"]/dataf["Good"].sum()
        dataf["I_V"]=(dataf["Good_per"]-dataf["Bad_per"])*np.log(dataf["Good_per"]/dataf["Bad_per"])
    return dataf

def df_crossjoin(df1,df2,**kwargs):
    df1['_tmpkey'] = 1
    df2['_tmpkey'] = 1
    res = pd.merge(df1,df2, on='_tmpkey',**kwargs).drop('_tmpkey',axis=1)
    res.index = pd.MultiIndex.from_product((df1.index,df2.index))
    df1.drop('_tmpkey',axis=1,inplace=True)
    df2.drop('_tmpkey',axis=1,inplace=True)
    return res


data=DataFrame(columns=('fr-num','fr-len','src-ip',
    'dst-ip','src-port','dst-port','num_get_post',
    'count-serv-src','count-serv-dst','num-packets-src-dst','num-packets-dst-src','label'))

path_dir =  "C:\\Users\\admin\\Desktop\\졸업프로젝트\\csv_파일들\\"
#'/home/ubuntu/Mechine-learning-model/normal-data/'
file_list = os.listdir(path_dir)
print(file_list)

for file_name in file_list:
    file_full_name = path_dir + file_name
    temp=pd.read_csv(file_full_name,names=['fr-num','fr-len','src-ip',
    'dst-ip','src-port','dst-port','num_get_post',
    'count-serv-src','count-serv-dst','num-packets-src-dst','num-packets-dst-src','label'],encoding='CP949')
    data=pd.concat([data,temp])

data=data.dropna(axis=0)
_columns=['fr-len','src-ip',
    'dst-ip','src-port','dst-port','num_get_post',
    'count-serv-src','count-serv-dst','num-packets-src-dst','num-packets-dst-src']
Iv_list=[]
for col in _columns:
    assigned_data=IV_calc(data=data,var=col)
    iv_val=round(assigned_data["I_V"].sum(),3)
    dt_type=data[col].dtypes
    Iv_list.append((iv_val,col,dt_type))
    print("Information_Value:",col)
    print(assigned_data)
    print("Total Information Value in ",col,":",assigned_data["I_V"].sum())

Iv_list=sorted(Iv_list,reverse=True)

for i in range(len(Iv_list)):
    print(Iv_list[i][0],",",Iv_list[i][1],",",Iv_list[i][2]) 

discrete_columns =['src-port','dst-port']
continuous_columns=['fr-len','src-ip','dst-ip','num_get_post','count-serv-src','count-serv-dst','num-packets-src-dst','num-packets-dst-src']

dummy_src_port=pd.get_dummies(data['src-port'],prefix='src_port:')
dummy_dst_port=pd.get_dummies(data['dst-port'],prefix='dst_port:')

new_data_con=data[continuous_columns]
new_data=pd.concat([new_data_con,data['src-port'],data['dst-port'],data['label']],axis=1)
#print(new_data)
x_train,x_test,y_train,y_test=train_test_split(new_data.drop(['label'],axis=1),new_data['label'],train_size=0.7,random_state=42)

remove_cols_=['fr-len','num_get_post','src-ip','dst-ip','src-port','dst-port']
remove_cols=list(set(remove_cols_))

x_train=x_train.drop(remove_cols,axis=1)
x_test=x_test.drop(remove_cols,axis=1)
y_train=pd.DataFrame(y_train)
y_test=pd.DataFrame(y_test)

logistic_model=sm.Logit(y_train.astype('float64'),sm.add_constant(x_train.astype('float64'))).fit()
print(logistic_model.summary())

print("Variance Inflation Factor")#VIF 값을 계산하여 다중공선성 진단
cnames=x_train.columns
for i in np.arange(0,len(cnames)):
    xvars=list(cnames)
    yvar=xvars.pop(i)
    mod=sm.OLS(x_train.astype('int')[yvar], sm.add_constant(x_train.astype('int'))[xvars])#최소자승법
    res=mod.fit()
    vif=1/(1-res.rsquared)
    print(yvar,round(vif,3))

#c 통계량
y_pred=pd.DataFrame(logistic_model.predict(sm.add_constant(x_train.astype('int'))))
y_pred.columns=["probs"]

both = pd.concat([y_train,y_pred],axis=1)
zeros = both[['label','probs']][both['label']==0]
ones = both[['label','probs']][both['label']==1]

joined_data = df_crossjoin(ones,zeros)
print(joined_data)

joined_data['concordant_pair'] = 0
joined_data.loc[joined_data['probs_x'] > joined_data['probs_y'],'concordant_pair'] = 1

joined_data['discordant_pair'] = 0
joined_data.loc[joined_data['probs_x'] < joined_data['probs_y'],'discordant_pair'] = 1
'''
joined_data['tied_pair'] = 0
joined_data.loc[joined_data['probs_x']== joined_data['probs_y'],'tied_pair'] = 1
'''
p_conc = (sum(joined_data['concordant_pair'])*1.0)/(joined_data.shape[0])
p_disc = (sum(joined_data['discordant_pair'])*1.0)/(joined_data.shape[0])

c_statistic = 0.5+ (p_conc-p_disc)/2.0
print("\nC-statistic:",round(c_statistic,4))

# ROC 곡선
'''
fpr, tpr, thresholds = metrics.roc_curve(both['label'].astype('int'),both['probs'].astype('float64'),pos_label=1) 
roc_auc= auc(fpr,tpr)
plt.figure()
lw=2
plt.plot(fpr,tpr,color='darkorange',lw=lw,label='ROC curve(area =%0.2f)' %roc_auc)
plt.plot([0,1],[0,1],color='navy',lw=lw,linestyle='--')
plt.xlim([0.0,1.0])
plt.ylim([0.0,1.05])
plt.xlabel('False Positive Rate (1-Specificity)')
plt.ylabel('True Positive Rate')
plt.title('ROC Curve - Normal-Malware Packet')
plt.legend(loc="lower right")
plt.show()
'''
#임계값 튜닝
for i in list(np.arange(0,1,0.1)):
    both["y_pred"] = 0
    both.loc[both["probs"]>i, "y_pred"]=1
    print("Threshold",i,"Train Accuracy:",round(accuracy_score(both['label'].astype('int'),both['y_pred'].astype('int')),4))

both["y_pred"]=0
both.loc[both["probs"]>0.5,'y_pred'] = 1
print("\nTrain Confusion Matrix \n\n",pd.crosstab(both['label'],both['y_pred'],rownames=["Actuall"],colnames=["Predicted"]))
print("\nTrain Accuracy:",round(accuracy_score(both['label'].astype('int'),both['y_pred'].astype('int')),4))

y_pred_test = pd.DataFrame(logistic_model.predict(sm.add_constant(x_test.astype('int'))))
y_pred_test.columns = ["probs"]
both_test = pd.concat([y_test,y_pred_test],axis=1)
both_test["y_pred"] = 0
both_test.loc[both_test["probs"]>0.5,"y_pred"]=1
print("\nTest Confusion Matrix\n\n",pd.crosstab(both_test['label'],both_test['y_pred'],rownames=["Actuall"],colnames=["Predicted"]))
print("\nTest Accuracy:",round(accuracy_score( both_test['label'].astype('int'),both_test['y_pred'].astype('int')),4))




