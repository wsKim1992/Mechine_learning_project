import os
import time
import threading
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import pandas as pd
import numpy as np 
import warnings 
from pandas import Series, DataFrame
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
#from sklearn.preprocessing import scale, robust_scale, minmax_scale,maxabs_scale
#from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score,classification_report
import matplotlib.pyplot as plt
warnings.filterwarnings('ignore')

def predicting(forest,data):
    print("Daemon Thread Start\n")
    print("Begin predicting\n")
    result = forest.predict(data)
    Sum=sum(result)
    print("result: ",result)
    if(Sum/len(result)<0.5):
        print("normal")
            
    else:
        print("malware")
    print("Daemon Thread Ends\n")


class Target:
    watchDir = "C:\\Users\\admin\\Desktop\\졸업프로젝트\\csv_파일들\\"
    def __init__(self):
        self.observer=Observer()

    def run(self):
        event_handler = Handler()
        self.observer.schedule(event_handler, self.watchDir, recursive=False)
        self.observer.start()
        try:
            while True:
                time.sleep(1)
        except:
            self.observer.stop()
            print("Error")
            self.observer.join()

class Handler(FileSystemEventHandler):
    def on_moved(self,event):
        print(event)
    def on_created(self,event):
        global continuous_columns
        global forest
        global remove_cols_
        print(event)
        print("파일생성됨!\n")
        new_path_dir = "C:\\Users\\admin\\Desktop\\졸업프로젝트\\실시간csv\\"
        new_file_list=os.listdir(new_path_dir)
        new_data_picked=DataFrame(columns=('fr-num','fr-len','src-ip',
        'dst-ip','src-port','dst-port','num_get_post',
        'count-serv-src','count-serv-dst','num-packets-src-dst','num-packets-dst-src'))
        for file_name in new_file_list:
            file_full_name = new_path_dir + file_name
            temp=pd.read_csv(file_full_name,names=['fr-num','fr-len','src-ip',
            'dst-ip','src-port','dst-port','num_get_post',
            'count-serv-src','count-serv-dst','num-packets-src-dst','num-packets-dst-src'],encoding='CP949')
            new_data_picked=pd.concat([new_data_picked,temp])
            print(new_data_picked)
            os.remove(file_full_name)
        new_data_picked=new_data_picekd.dropna(axis=0)
        new_data_picked=new_data_picked.drop('fr-num',axis=1)
        new_data_picked_con=new_data_picked[continuous_columns]

        dum_s_port=pd.get_dummies(new_data_picked['src-port'],prefix='src-port:#')
        dum_d_port=pd.get_dummies(new_data_picked['src-port'],prefix='src-port:#')

        complete_data=pd.concat([new_data_picked_con,dum_s_port,dum_d_port],axis=1)
        complete_data=complete_data.drop(remove_cols,axis=1)
        th = threading.Thread(target=predicting,args=(forest,complete_data))
        th.daemon = True
        th.start()
        
    def on_deleted(self,event):
        print(event)
    def on_modified(self,event):
        print(event)    

data=DataFrame(columns=('fr-num','fr-len','src-ip',
    'dst-ip','src-port','dst-port','num_get_post',
    'count-serv-src','count-serv-dst','num-packets-src-dst','num-packets-dst-src','label'))

path_dir =  "C:\\Users\\admin\\Desktop\\졸업프로젝트\\csv_파일들\\"
#'/home/ubuntu/Mechine-learning-model/normal-data/'
file_list = os.listdir(path_dir)
print(file_list)

for file_name in file_list:
    file_full_name = path_dir + file_name
    temp=pd.read_csv(file_full_name,names=['fr-num','fr-len','src-ip',
    'dst-ip','src-port','dst-port','num_get_post',
    'count-serv-src','count-serv-dst','num-packets-src-dst','num-packets-dst-src','label'],encoding='CP949')
    data=pd.concat([data,temp])

data=data.dropna(axis=0)#csv 파일에서 빈 row들(na값이 있는)을 모두 제거하여 에러가 안뜨게 하기 위함 axis=0은 row를 의미
dummy_src_port=pd.get_dummies(data['src-port'],prefix='src-port:#')#연속형 변수가 아닌 범주형 변수인 source port 번호와 destination port 번호를
dummy_dst_port=pd.get_dummies(data['dst-port'],prefix='dst-port:#')#더미 변수로 변환하여 연속형 변수처럼 만들어 주었다

continuous_columns=['fr-len','src-ip',
    'dst-ip','num_get_post','count-serv-src','count-serv-dst','num-packets-src-dst','num-packets-dst-src']#기존의 연속형 변수들의 tag들이다
data_continuous=data[continuous_columns]#새로운 dataset 을 만든다
new_data=pd.concat([data_continuous,dummy_src_port,dummy_dst_port,data['label']],axis=1)#세로운 dataset에 더미변수로 변환한 포트번호 변수들과 결과값을 포함하고 있는 column들을 추가 하였다.
new_data=new_data.dropna(axis=1)
X_train,X_test,Y_train,Y_test = train_test_split(new_data.drop('label',axis=1),new_data['label'],test_size=0.7,random_state=42)#test dataset 들과 train dataset 들을 3:7로 분리 하였다.

remove_cols_=['num_get_post','src-ip','dst-ip','fr-len']#높은 IV 값을 가진 변수들 제거하고 학습
remove_cols=list(set(remove_cols_))
X_train=X_train.drop(remove_cols,axis=1)
X_test=X_test.drop(remove_cols,axis=1)

forest=RandomForestClassifier(n_estimators=1000,criterion="gini",max_depth=100,min_samples_split=3,min_samples_leaf=2)#결정트리의 개수는 1000개 지니(GINI)계수방정식으로 데이터를 분할할 기준을 정한다.
forest.fit(X_train,Y_train.astype('int'))

print("\nRandom Forest -Train Confusion Matrix\n\n",#훈련시킨 결과
pd.crosstab(Y_train, forest.predict(X_train),rownames = ['Actuall'],colnames = ['Predicted']))

print("\nRandom Forest - Test Classification Report\n",classification_report(Y_test.astype('int'),forest.predict(X_test)))
print("\n Random Forest - Test accuracy ",round(accuracy_score(Y_test.astype('int'),forest.predict(X_test)),3))

print("\nRandom Forest -Train Confusion Matrix\n\n",#test dataset으로 예측해본 결과
pd.crosstab(Y_test, forest.predict(X_test),rownames = ['Actuall'],colnames = ['Predicted']))

print("\nRandom Forest - Train Classification Report\n",classification_report(Y_train.astype('int'),forest.predict(X_train)))
print("\n Random Forest - Test accuracy ",round(accuracy_score(Y_train.astype('int'),forest.predict(X_train)),3))

print("\n지금부터 실시간 감시 시작\n")
w=Target()
w.run()
